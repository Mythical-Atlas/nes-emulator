﻿using GLFW;
using OpenTK;
using OpenTK.Audio.OpenAL;
using NES.GameLoop;
using NES.Rendering;
using NES.Rendering.Display;
using StbiSharp;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Numerics;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

using static NES.OpenGL.GL;
using NES.Emulation;

namespace NES {
	class MainState : State {
		uint vao;
		uint vbo;

		Shader shader;
		Camera cam;

		public MainState(int initialWindowWidth, int initialWindowHeight, string initialWindowTitle) : base(initialWindowWidth, initialWindowHeight, initialWindowTitle) {}

		protected override void Initialize() {
			cam = new Camera((256 * Program.Scale) / 2, (240 * Program.Scale) / 2, 1, 0);
		}

		protected unsafe override void LoadContent() {
			string vertexShader = @"
				#version 330 core
			
				out vec4 vertexColor;

				layout (location = 0) in vec2 aPosition;
                layout (location = 1) in vec4 aColor;

				uniform mat4 projection;
    
                void main() {
					gl_Position = projection * vec4(aPosition.xy, 0, 1.0);
                    vertexColor = aColor;
                }
			";

			string fragmentShader = @"
				#version 330 core

				out vec4 FragColor;

				in vec4 vertexColor;

				void main() {
					FragColor = vertexColor;
				}
			";

			glEnable(GL_BLEND);
			glBlendFuncSeparate(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA, GL_ONE, GL_ONE);

			shader = new Shader(vertexShader, fragmentShader);
			shader.Load();

			vao = glGenVertexArray();
			vbo = glGenBuffer();

			Emulator.Initialize();
		}

		protected override void Update() {
			Emulator.Update();
		}

		protected override void Render() {
			Emulator.Render(vao, vbo, shader, cam);

			Glfw.SwapBuffers(DisplayManager.Window);
		}

		protected override void KeyCallback(IntPtr window, Keys key, int scanCode, InputState state, ModifierKeys mods) {
			switch(key) {
				case(Keys.A): {
					if(state == InputState.Press) {Controller.a = true;}
					if(state == InputState.Release) {Controller.a = false;}
                    break;
				}
				case(Keys.B): {
					if(state == InputState.Press) {Controller.b = true;}
					if(state == InputState.Release) {Controller.b = false;}
                    break;
				}
				case(Keys.Backspace): {
					if(state == InputState.Press) {Controller.select = true;}
					if(state == InputState.Release) {Controller.select = false;}
                    break;
				}
                case(Keys.Enter): {
					if(state == InputState.Press) {Controller.start = true;}
					if(state == InputState.Release) {Controller.start = false;}
                    break;
				}
				case(Keys.Up): {
					if(state == InputState.Press) {Controller.up = true;}
					if(state == InputState.Release) {Controller.up = false;}
                    break;
				}
                case(Keys.Down): {
					if(state == InputState.Press) {Controller.down = true;}
					if(state == InputState.Release) {Controller.down = false;}
                    break;
				}
				case(Keys.Left): {
					if(state == InputState.Press) {Controller.left = true;}
					if(state == InputState.Release) {Controller.left = false;}
                    break;
				}
                case(Keys.Right): {
					if(state == InputState.Press) {Controller.right = true;}
					if(state == InputState.Release) {Controller.right = false;}
                    break;
				}
            }
		}
	}
}
