﻿using System;
using NES.Emulation;
using NES.GameLoop;

namespace NES {
	class Program {
		public static int Scale = 4;

		static State state;

		static void Main(string[] args) {
			state = new MainState(256 * Scale, 240 * Scale, "Ben Correll's C# NES Emulator");
			state.Run();
		}
	}
}
