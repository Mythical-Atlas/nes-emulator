﻿using GLFW;
using NES.Rendering.Display;
using NES.GameLoop;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NES.GameLoop {
	abstract class State {
		protected int InitialWindowWidth {get; set;}
		protected int InitialWindowHeight {get; set;}
		protected string InitialWindowTitle {get; set;}

		public State(int initialWindowWidth, int initialWindowHeight, string initialWindowTitle) {
			InitialWindowWidth = initialWindowWidth;
			InitialWindowHeight = initialWindowHeight;
			InitialWindowTitle = initialWindowTitle;
		}

		public void Run() {
			Initialize();

			DisplayManager.CreateWindow(InitialWindowWidth, InitialWindowHeight, InitialWindowTitle);

			LoadContent();

			while(!Glfw.WindowShouldClose(DisplayManager.Window)) {
				float startTime = (float)Glfw.Time;

				Update();

				Glfw.PollEvents();

				Glfw.SetKeyCallback(DisplayManager.Window, KeyCallback);

				Render();

				float elapsedTime = startTime - (float)Glfw.Time;
				float timeDifference = elapsedTime - 1 / 60;
				if(timeDifference > 0) {System.Threading.Thread.Sleep((int)(timeDifference * 1000));}
			}

			DisplayManager.CloseWindow();
		}

		protected abstract void Initialize();
		protected abstract void LoadContent();

		protected abstract void Update();
		protected abstract void Render();

		protected abstract void KeyCallback(IntPtr window, Keys key, int scanCode, InputState state, ModifierKeys mods);
	}
}
