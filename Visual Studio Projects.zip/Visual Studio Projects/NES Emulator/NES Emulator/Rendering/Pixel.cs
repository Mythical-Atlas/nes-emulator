﻿using NES.Rendering;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Numerics;
using System.Text;
using System.Threading.Tasks;

using static NES.OpenGL.GL;

namespace NES.Rendering {
	class Pixel {
		Vector2 position;
		Vector4 color;

		public Pixel(Vector2 position) {this.position = position;}

		public void SetPosition(Vector2 position) {this.position = position;}
		public void SetColor(Vector4 color) {this.color = color;}

		public float[] GetVertices() {
			float x = position.X * Program.Scale;
			float y = position.Y * Program.Scale;
			float w = Program.Scale;
			float h = Program.Scale;

			float[] vertices = {
				x,     y,	    color.X, color.Y, color.Z, color.W, // top left
				x + w, y,	    color.X, color.Y, color.Z, color.W, // top right
				x,     y + h,   color.X, color.Y, color.Z, color.W, // bottom left

				x + w, y,    	color.X, color.Y, color.Z, color.W, // top right
				x + w, y + h,	color.X, color.Y, color.Z, color.W, // bottom right
				x,     y + h,	color.X, color.Y, color.Z, color.W, // bottom left
			};

			return(vertices);
		}
	}
}
