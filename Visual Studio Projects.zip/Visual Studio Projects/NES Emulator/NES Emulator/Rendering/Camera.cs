﻿using NES.Rendering.Display;
using NES.Rendering;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Numerics;
using System.Text;
using System.Threading.Tasks;

namespace NES.Rendering {
	class Camera {
		Vector2 position;
		float scale;
		float rotation;

		public Camera(Vector2 position, float zoom, float rotation) {
			this.position = position;
			scale = zoom;
			this.rotation = rotation;
		}
		public Camera(float x, float y, float zoom, float rotation) {
			position = new Vector2(x, y);
			scale = zoom;
			this.rotation = rotation;
		}
		public Camera() {
			position = Vector2.Zero;
			scale = 1;
			rotation = 0;
		}

		public void Translate(float x, float y) {position += new Vector2(x, y);}
		public void Translate(Vector2 delta) {position += delta;}
		public void Zoom(float delta) {scale += delta;}
		public void Rotate(float delta) {rotation +=  delta;}

		public Matrix4x4 GetProjectionMatrix() {
			float left = -DisplayManager.WindowSize.X / 2;
			float right = DisplayManager.WindowSize.X / 2;
			float top = -DisplayManager.WindowSize.Y / 2;
			float bottom = DisplayManager.WindowSize.Y / 2;

			Matrix4x4 orthoMatrix = Matrix4x4.CreateOrthographicOffCenter(left, right, bottom, top, 0.01f, 100f);
			Matrix4x4 zoomMatrix = Matrix4x4.CreateScale(scale);

			return(orthoMatrix * zoomMatrix);
		}

		public void Bind(Shader shader) {shader.SetMatrix4x4("projection", Matrix4x4.CreateTranslation(-position.X, -position.Y, 0) * Matrix4x4.CreateRotationZ(rotation) * GetProjectionMatrix());}
	}
}
