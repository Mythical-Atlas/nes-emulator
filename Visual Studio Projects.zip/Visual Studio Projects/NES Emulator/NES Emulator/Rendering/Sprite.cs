﻿using NES.Rendering;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Numerics;
using System.Text;
using System.Threading.Tasks;

using static NES.OpenGL.GL;

namespace NES.Rendering {
	class Sprite {
		Pixel[] pixels;

		public Sprite(Vector2 position) {
			pixels = new Pixel[8 * 8];
			for(int x = 0; x < 8; x++) {for(int y = 0; y < 8; y++) {pixels[x + y * 8] = new Pixel(new Vector2(position.X + x, position.Y + y));}}
		}

		public void SetPixel(Vector2 position, Vector4 color) {pixels[(int)position.X + (int)position.Y * 8].SetColor(color);}

		public unsafe void Load(uint vao, uint vbo) {
			glBindVertexArray(vao);
			glBindBuffer(GL_ARRAY_BUFFER, vbo);

			float[] vertices = new float[36 * 8 * 8];
			for(int x = 0; x < 8; x++) {
				for(int y = 0; y < 8; y++) {
					float[] tempVerts = pixels[x + y * 8].GetVertices();
					for(int i = 0; i < 36; i++) {vertices[(x + y * 8) * 36 + i] = tempVerts[i];}
				}
			}

			fixed(float* v = &vertices[0]) {glBufferData(GL_ARRAY_BUFFER, sizeof(float) * vertices.Length, v, GL_DYNAMIC_DRAW);}

			glVertexAttribPointer(0, 2, GL_FLOAT, false, 6 * sizeof(float), (void*)0);
			glEnableVertexAttribArray(0);

			glVertexAttribPointer(1, 4, GL_FLOAT, false, 6 * sizeof(float), (void*)(2 * sizeof(float)));
			glEnableVertexAttribArray(1);

			glBindBuffer(GL_ARRAY_BUFFER, 0);
			glBindVertexArray(0);
		}

		public void Render(uint vao, uint vbo, Shader shader, Camera cam) {
			shader.Use();
			cam.Bind(shader);

			glBindVertexArray(vao);

			glDrawArrays(GL_TRIANGLES, 0, 6 * 8 * 8); // take advantage of this and just throw all the pixels in one aray

			glBindVertexArray(0);
		}
	}
}
