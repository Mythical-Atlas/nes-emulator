﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Numerics;
using System.Text;
using System.Threading.Tasks;

namespace NES.Rendering {
	class Colors {
		public static Vector3[] Values = new Vector3[]{
			new Vector3( 84,  84,  84), new Vector3(  0,  30, 116), new Vector3(  8,  16, 144), new Vector3( 48,   0, 136), new Vector3( 68,   0, 100), new Vector3( 92,   0,  48), new Vector3( 84,   4,   0), new Vector3( 60,  24,   0), new Vector3( 32,  42,   0), new Vector3(  8,  58,   0), new Vector3(  0,  64,   0), new Vector3(  0,  60,   0), new Vector3(  0,  50,  60), new Vector3(  0,   0,   0), new Vector3(  0,   0,   0), new Vector3(  0,   0,   0),
			new Vector3(152, 150, 152), new Vector3(  8,  76, 196), new Vector3( 48,  50, 236), new Vector3( 92,  30, 228), new Vector3(136,  20, 176), new Vector3(160,  20, 100), new Vector3(152,  34,  32), new Vector3(120,  60,   0), new Vector3( 84,  80,   0), new Vector3( 40, 114,   0), new Vector3(  8, 124,   0), new Vector3(  0, 118,  40), new Vector3(  0, 102, 120), new Vector3(  0,   0,   0), new Vector3(  0,   0,   0), new Vector3(  0,   0,   0),
			new Vector3(236, 238, 236), new Vector3( 76, 154, 236), new Vector3(120, 124, 236), new Vector3(176,  98, 236), new Vector3(228,  84, 236), new Vector3(236,  88, 180), new Vector3(236, 106, 100), new Vector3(212, 136,  32), new Vector3(160, 170,   0), new Vector3(116, 196,   0), new Vector3( 76, 208,  32), new Vector3( 56, 204, 108), new Vector3( 56, 180, 204), new Vector3( 60,  60,  60), new Vector3(  0,   0,   0), new Vector3(  0,   0,   0),
			new Vector3(236, 238, 236), new Vector3(168, 204, 236), new Vector3(188, 188, 236), new Vector3(212, 178, 236), new Vector3(236, 174, 236), new Vector3(236, 174, 212), new Vector3(236, 180, 176), new Vector3(228, 196, 144), new Vector3(204, 210, 120), new Vector3(180, 222, 120), new Vector3(168, 226, 144), new Vector3(152, 226, 180), new Vector3(160, 214, 228), new Vector3(160, 162, 160), new Vector3(  0,   0,   0), new Vector3(  0,   0,   0),
		};
	}
}
