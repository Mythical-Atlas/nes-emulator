﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NES.Components;

using static NES.Convenience;

namespace NES {
	class AddressingModes {
		public static ushort Immediate() {return((ushort)(CPU.pc + 1));}
		public static ushort ZeroPage() {return(Memory.ReadByte((ushort)(CPU.pc + 1)));}
		public static ushort ZeroPageX() {
			if((Memory.ReadByte((ushort)(CPU.pc + 1)) & 0xFF00) != ((ushort)(Memory.ReadByte((ushort)(CPU.pc + 1)) + CPU.x) & 0xFF00)) {CPU.cycles++;}
			return((byte)(Memory.ReadByte((ushort)(CPU.pc + 1)) + CPU.x));
		}
		public static ushort ZeroPageY() {
			if((Memory.ReadByte((ushort)(CPU.pc + 1)) & 0xFF00) != ((ushort)(Memory.ReadByte((ushort)(CPU.pc + 1)) + CPU.y) & 0xFF00)) {CPU.cycles++;}
			return((byte)(Memory.ReadByte((ushort)(CPU.pc + 1)) + CPU.y));
		}
		public static ushort Relative() {return((ushort)(CPU.pc + (sbyte)Memory.ReadByte((ushort)(CPU.pc + 1))));}
		public static ushort Absolute() {return(Memory.ReadShort((ushort)(CPU.pc + 1)));}
		public static ushort AbsoluteX() {
			if((Memory.ReadShort((ushort)(CPU.pc + 1)) & 0xFF00) != ((ushort)(Memory.ReadShort((ushort)(CPU.pc + 1)) + CPU.x) & 0xFF00)) {CPU.cycles++;}
			return((ushort)(Memory.ReadShort((ushort)(CPU.pc + 1)) + CPU.x));
		}
		public static ushort AbsoluteY() {
			if((Memory.ReadShort((ushort)(CPU.pc + 1)) & 0xFF00) != ((ushort)(Memory.ReadShort((ushort)(CPU.pc + 1)) + CPU.y) & 0xFF00)) {CPU.cycles++;}
			return((ushort)(Memory.ReadShort((ushort)(CPU.pc + 1)) + CPU.y));
		}
		public static ushort Indirect() {return(Memory.ReadShort(Memory.ReadShort((ushort)(CPU.pc + 1))));}
		public static ushort IndirectX() {return(Memory.ReadShort((ushort)(Memory.ReadByte((ushort)(CPU.pc + 1)) + CPU.x)));}
		public static ushort IndirectY() {
			if((Memory.ReadShort(Memory.ReadByte((ushort)(CPU.pc + 1))) & 0xFF00) != ((ushort)(Memory.ReadShort(Memory.ReadByte((ushort)(CPU.pc + 1))) + CPU.y) & 0xFF00)) {CPU.cycles++;}
			return((ushort)(Memory.ReadShort(Memory.ReadByte((ushort)(CPU.pc + 1))) + CPU.y));
		}
	}
}