﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NES.Emulation {
	class Controller {
		public static bool up;
		public static bool down;
		public static bool left;
		public static bool right;
		public static bool a;
		public static bool b;
		public static bool start;
		public static bool select;
		
		static int status;

		public static void Write(byte value) {
			if((value & 1) == 1) {status = 1;}
			else if((value & 1) == 0 && status == 1) {status = 2;}
		}

		public static byte Read() {
			if(status == 2) {
				status++;
				if(a) {return(0x41);}
				if(!a) {return(0x40);}
			}
			else if(status == 3) {
				status++;
				if(b) {return(0x41);}
				if(!b) {return(0x40);}
			}
			else if(status == 4) {
				status++;
				if(select) {return(0x41);}
				if(!select) {return(0x40);}
			}
			else if(status == 5) {
				status++;
				if(start) {return(0x41);}
				if(!start) {return(0x40);}
			}
			else if(status == 6) {
				status++;
				if(up) {return(0x41);}
				if(!up) {return(0x40);}
			}
			else if(status == 7) {
				status++;
				if(down) {return(0x41);}
				if(!down) {return(0x40);}
			}
			else if(status == 8) {
				status++;
				if(left) {return(0x41);}
				if(!left) {return(0x40);}
			}
			else if(status == 9) {
				status++;
				if(right) {return(0x41);}
				if(!right) {return(0x40);}
			}
			else if(status == 10) {return(0x40);}
			return(0);
		}
	}
}
