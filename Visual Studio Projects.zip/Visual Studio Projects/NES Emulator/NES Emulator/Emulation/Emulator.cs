﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Numerics;
using System.Text;
using System.Threading.Tasks;
using NES.Components;
using NES.GameLoop;
using NES.Rendering;

namespace NES.Emulation {
	class Emulator {
		const int ClockHertz = 21477272;
		const int CPUClockDivisor = 12;
		const int PPUClockDivisor = 4;
		const int TargetPeriod = 60;
		const int TargetFrequency = 27;

		public static bool Running {get; set;}

		public static void Initialize() {
			ROM.Load("../../../Assets/Metroid.nes");
			Memory.Initialize();
			CPU.Initialize();
			PPU.Initialize();
		}

		public static void Update() {
			for(int c = 0; c < ClockHertz / CPUClockDivisor / TargetFrequency; c++) {
				CPU.Step();
				for(int p = 0; p < CPUClockDivisor / PPUClockDivisor; p++) {PPU.Step();}
			}
		}

		public static void Render(uint vao, uint vbo, Shader shader, Camera cam) {
			PPU.Render(vao, vbo, shader, cam);
		}
	}
}
