﻿using NES.Components;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using static NES.Convenience;
using static NES.AddressingModes;

namespace NES {
	class Operations {
		public static void CLC() {CPU.sr = SetBit(CPU.sr, 0, false);}
		public static void CLI() {CPU.sr = SetBit(CPU.sr, 2, false);}
		public static void CLD() {CPU.sr = SetBit(CPU.sr, 3, false);}
		public static void CLV() {CPU.sr = SetBit(CPU.sr, 6, false);}

		public static void SEC() {CPU.sr = SetBit(CPU.sr, 0, true);}
		public static void SEI() {CPU.sr = SetBit(CPU.sr, 2, true);}
		public static void SED() {CPU.sr = SetBit(CPU.sr, 3, true);}
		public static void SEV() {CPU.sr = SetBit(CPU.sr, 6, true);}

		public static void LDA(ushort address) {
			CPU.a = Memory.ReadByte(address);
			CPU.sr = SetBit(CPU.sr, 7, GetBit(CPU.a, 7));
			CPU.sr = SetBit(CPU.sr, 1, CPU.a == 0);
		}
		public static void LDX(ushort address) {
			CPU.x = Memory.ReadByte(address);
			CPU.sr = SetBit(CPU.sr, 7, GetBit(CPU.x, 7));
			CPU.sr = SetBit(CPU.sr, 1, CPU.x == 0);
		}
		public static void LDY(ushort address) {
			CPU.y = Memory.ReadByte(address);
			CPU.sr = SetBit(CPU.sr, 7, GetBit(CPU.y, 7));
			CPU.sr = SetBit(CPU.sr, 1, CPU.y == 0);
		}

		public static void STA(ushort address) {Memory.WriteByte(address, CPU.a);}
		public static void STX(ushort address) {Memory.WriteByte(address, CPU.x);}
		public static void STY(ushort address) {Memory.WriteByte(address, CPU.y);}

		public static void JMP(ushort address) {CPU.pc = address;}

		public static void JSR(ushort address) {
			Memory.PushShort((ushort)(CPU.pc + 2));
			CPU.pc = address;
		}

		public static void RTS() {
			CPU.pc = Memory.PopShort();
		}
		public static void RTI() {
			CPU.sr = Memory.PopByte();
			CPU.pc = Memory.PopShort();
		}

		public static void BPL(ushort address) {
			if(!GetBit(CPU.sr, 7)) {
				CPU.cycles++;
				if((CPU.pc & 0xFF00) != (address & 0xFF00)) {
					CPU.cycles++;
				}
				CPU.pc = address;
			}
		}
		public static void BMI(ushort address) {
			if(GetBit(CPU.sr, 7)) {
				CPU.cycles++;
				if((CPU.pc & 0xFF00) != (address & 0xFF00)) {
					CPU.cycles++;
				}
				CPU.pc = address;
			}
		}
		public static void BNE(ushort address) {
			if(!GetBit(CPU.sr, 1)) {
				CPU.cycles++;
				if((CPU.pc & 0xFF00) != (address & 0xFF00)) {
					CPU.cycles++;
				}
				CPU.pc = address;
			}
		}
		public static void BEQ(ushort address) {
			if(GetBit(CPU.sr, 1)) {
				CPU.cycles++;
				if((CPU.pc & 0xFF00) != (address & 0xFF00)) {
					CPU.cycles++;
				}
				CPU.pc = address;
			}
		}
		public static void BCC(ushort address) {
			if(!GetBit(CPU.sr, 0)) {
				CPU.cycles++;
				if((CPU.pc & 0xFF00) != (address & 0xFF00)) {
					CPU.cycles++;
				}
				CPU.pc = address;
			}
		}
		public static void BCS(ushort address) {
			if(GetBit(CPU.sr, 0)) {
				CPU.cycles++;
				if((CPU.pc & 0xFF00) != (address & 0xFF00)) {
					CPU.cycles++;
				}
				CPU.pc = address;
			}
		}
		public static void BVC(ushort address) {
			if(!GetBit(CPU.sr, 6)) {
				CPU.cycles++;
				if((CPU.pc & 0xFF00) != (address & 0xFF00)) {
					CPU.cycles++;
				}
				CPU.pc = address;
			}
		}
		public static void BVS(ushort address) {
			if(GetBit(CPU.sr, 6)) {
				CPU.cycles++;
				if((CPU.pc & 0xFF00) != (address & 0xFF00)) {
					CPU.cycles++;
				}
				CPU.pc = address;
			}
		}

		public static void AND(ushort address) {
			CPU.a &= Memory.ReadByte(address);
			CPU.sr = SetBit(CPU.sr, 7, GetBit(CPU.a, 7));
			CPU.sr = SetBit(CPU.sr, 1, CPU.a == 0);
		}

		public static void ORA(ushort address) {
			CPU.a |= Memory.ReadByte(address);
			CPU.sr = SetBit(CPU.sr, 7, GetBit(CPU.a, 7));
			CPU.sr = SetBit(CPU.sr, 1, CPU.a == 0);
		}

		public static void EOR(ushort address) {
			CPU.a ^= Memory.ReadByte(address);
			CPU.sr = SetBit(CPU.sr, 7, GetBit(CPU.a, 7));
			CPU.sr = SetBit(CPU.sr, 1, CPU.a == 0);
		}

		public static void LSR() {
			CPU.sr = SetBit(CPU.sr, 0, GetBit(CPU.a, 0));
			CPU.a = (byte)(CPU.a >> 1);
			CPU.sr = SetBit(CPU.sr, 7, GetBit(CPU.a, 7));
			CPU.sr = SetBit(CPU.sr, 1, CPU.a == 0);
		}
		public static void LSR(ushort address) {
			CPU.sr = SetBit(CPU.sr, 0, GetBit(Memory.ReadByte(address), 0));
			Memory.WriteByte(address, (byte)(Memory.ReadByte(address) >> 1));
			CPU.sr = SetBit(CPU.sr, 7, GetBit(Memory.ReadByte(address), 7));
			CPU.sr = SetBit(CPU.sr, 1, Memory.ReadByte(address) == 0);
		}
		public static void ASL() {
			CPU.sr = SetBit(CPU.sr, 0, GetBit(CPU.a, 7));
			CPU.a = (byte)(CPU.a << 1);
			CPU.sr = SetBit(CPU.sr, 7, GetBit(CPU.a, 7));
			CPU.sr = SetBit(CPU.sr, 1, CPU.a == 0);
		}
		public static void ASL(ushort address) {
			CPU.sr = SetBit(CPU.sr, 0, GetBit(Memory.ReadByte(address), 7));
			Memory.WriteByte(address, (byte)(Memory.ReadByte(address) << 1));
			CPU.sr = SetBit(CPU.sr, 7, GetBit(Memory.ReadByte(address), 7));
			CPU.sr = SetBit(CPU.sr, 1, Memory.ReadByte(address) == 0);
		}
		
		public static void ROL() {
			bool temp = GetBit(CPU.a, 7);

			CPU.a = (byte)(CPU.a << 1);
			CPU.a = SetBit(CPU.a, 0, GetBit(CPU.sr, 0));
			CPU.sr = SetBit(CPU.sr, 0, temp);
			CPU.sr = SetBit(CPU.sr, 7, GetBit(CPU.a, 7));
			CPU.sr = SetBit(CPU.sr, 1, CPU.a == 0);
		}
		public static void ROL(ushort address) {
			bool temp = GetBit(Memory.ReadByte(address), 7);

			Memory.WriteByte(address, (byte)(Memory.ReadByte(address) << 1));
			Memory.WriteByte(address, SetBit(Memory.ReadByte(address), 0, GetBit(CPU.sr, 0)));
			CPU.sr = SetBit(CPU.sr, 0, temp);
			CPU.sr = SetBit(CPU.sr, 7, GetBit(Memory.ReadByte(address), 7));
			CPU.sr = SetBit(CPU.sr, 1, Memory.ReadByte(address) == 0);
		}
		public static void ROR() {
			bool temp = GetBit(CPU.a, 0);

			CPU.a = (byte)(CPU.a >> 1);
			CPU.a = SetBit(CPU.a, 7, GetBit(CPU.sr, 0));
			CPU.sr = SetBit(CPU.sr, 0, temp);
			CPU.sr = SetBit(CPU.sr, 7, GetBit(CPU.a, 7));
			CPU.sr = SetBit(CPU.sr, 1, CPU.a == 0);
		}
		public static void ROR(ushort address) {
			bool temp = GetBit(Memory.ReadByte(address), 0);

			Memory.WriteByte(address, (byte)(Memory.ReadByte(address) >> 1));
			Memory.WriteByte(address, SetBit(Memory.ReadByte(address), 7, GetBit(CPU.sr, 0)));
			CPU.sr = SetBit(CPU.sr, 0, temp);
			CPU.sr = SetBit(CPU.sr, 7, GetBit(CPU.a, 7));
			CPU.sr = SetBit(CPU.sr, 1, Memory.ReadByte(address) == 0);
		}

		public static void INX() {
			CPU.x++;
			CPU.sr = SetBit(CPU.sr, 7, GetBit(CPU.x, 7));
			CPU.sr = SetBit(CPU.sr, 1, CPU.x == 0);
		}
		public static void INY() {
			CPU.y++;
			CPU.sr = SetBit(CPU.sr, 7, GetBit(CPU.y, 7));
			CPU.sr = SetBit(CPU.sr, 1, CPU.y == 0);
		}

		public static void INC(ushort address) {
			Memory.WriteByte(address, (byte)(Memory.ReadByte(address) + 1));
			CPU.sr = SetBit(CPU.sr, 7, GetBit(Memory.ReadByte(address), 7));
			CPU.sr = SetBit(CPU.sr, 1, Memory.ReadByte(address) == 0);
		}

		public static void DEX() {
			CPU.x--;
			CPU.sr = SetBit(CPU.sr, 7, GetBit(CPU.x, 7));
			CPU.sr = SetBit(CPU.sr, 1, CPU.x == 0);
		}
		public static void DEY() {
			CPU.y--;
			CPU.sr = SetBit(CPU.sr, 7, GetBit(CPU.y, 7));
			CPU.sr = SetBit(CPU.sr, 1, CPU.y == 0);
		}

		public static void TXA() {CPU.a = CPU.x;}
		public static void TXS() {CPU.sp = CPU.x;}

		public static void TYA() {
			CPU.a = CPU.y;
			CPU.sr = SetBit(CPU.sr, 7, GetBit(CPU.a, 7));
			CPU.sr = SetBit(CPU.sr, 1, CPU.a == 0);
		}
		public static void TAX() {
			CPU.x = CPU.a;
			CPU.sr = SetBit(CPU.sr, 7, GetBit(CPU.x, 7));
			CPU.sr = SetBit(CPU.sr, 1, CPU.x == 0);
		}
		public static void TAY() {
			CPU.y = CPU.a;
			CPU.sr = SetBit(CPU.sr, 7, GetBit(CPU.y, 7));
			CPU.sr = SetBit(CPU.sr, 1, CPU.y == 0);
		}

		public static void DEC(ushort address) {
			Memory.WriteByte(address, (byte)(Memory.ReadByte(address) - 1));
			CPU.sr = SetBit(CPU.sr, 7, GetBit(Memory.ReadByte(address), 7));
			CPU.sr = SetBit(CPU.sr, 1, Memory.ReadByte(address) == 0);
		}

		public static void CMP(ushort address) {
			byte temp = (byte)(CPU.a - Memory.ReadByte(address));

			CPU.sr = SetBit(CPU.sr, 7, GetBit(temp, 7));
			CPU.sr = SetBit(CPU.sr, 1, temp == 0);
			CPU.sr = SetBit(CPU.sr, 0, CPU.a >= Memory.ReadByte(address));
		}
		public static void CPX(ushort address) {
			byte temp = (byte)(CPU.x - Memory.ReadByte(address));

			CPU.sr = SetBit(CPU.sr, 7, GetBit(temp, 7));
			CPU.sr = SetBit(CPU.sr, 1, temp == 0);
			CPU.sr = SetBit(CPU.sr, 0, CPU.x >= Memory.ReadByte(address));
		}
		public static void CPY(ushort address) {
			byte temp = (byte)(CPU.y - Memory.ReadByte(address));

			CPU.sr = SetBit(CPU.sr, 7, GetBit(temp, 7));
			CPU.sr = SetBit(CPU.sr, 1, temp == 0);
			CPU.sr = SetBit(CPU.sr, 0, CPU.y >= Memory.ReadByte(address));
		}

		public static void BIT(ushort address) {
			CPU.sr = SetBit(CPU.sr, 7, GetBit(Memory.ReadByte(address), 7));
			CPU.sr = SetBit(CPU.sr, 6, GetBit(Memory.ReadByte(address), 6));
			CPU.sr = SetBit(CPU.sr, 1, (CPU.a & Memory.ReadByte(address)) == 0);
		}

		public static void PLA() {
			CPU.a = Memory.PopByte();
			CPU.sr = SetBit(CPU.sr, 7, GetBit(CPU.a, 7));
			CPU.sr = SetBit(CPU.sr, 1, CPU.a == 0);
		}
		public static void PLP() {CPU.sr = Memory.PopByte();}

		public static void PHA() {Memory.PushByte(CPU.a);}
		public static void PHP() {Memory.PushByte(CPU.sr);}

		public static void ADC(ushort address) {
			byte m = CPU.a;
			byte n = Memory.ReadByte(address);
			byte c = 0;
			if(GetBit(CPU.sr, 0)) {c++;}

			CPU.a = (byte)(m + n + c);

			CPU.sr = SetBit(CPU.sr, 7, GetBit(CPU.a, 7));
			CPU.sr = SetBit(CPU.sr, 6, GetBit(m, 7) && GetBit(n, 7) && m + n + c <= 0xFF || !GetBit(m, 7) && !GetBit(n, 7) && m + n + c > 0xFF);
			CPU.sr = SetBit(CPU.sr, 1, CPU.a == 0);
			CPU.sr = SetBit(CPU.sr, 0, m + n + c > 0xFF);
		}

		public static void SBC(ushort address) { // not extremely confident
			byte m = CPU.a;
			byte n = (byte)((sbyte)(-Memory.ReadByte(address)));
			byte c = 0xFF;
			if(GetBit(CPU.sr, 0)) {c = 0;}

			CPU.a = (byte)(m + n + c);

			CPU.sr = SetBit(CPU.sr, 7, GetBit(CPU.a, 7));
			CPU.sr = SetBit(CPU.sr, 6, GetBit(m, 7) && GetBit(n, 7) && m + n + c <= 0xFF || !GetBit(m, 7) && !GetBit(n, 7) && m + n + c > 0xFF);
			CPU.sr = SetBit(CPU.sr, 1, CPU.a == 0);
			CPU.sr = SetBit(CPU.sr, 0, m + n + c > 0xFF || m == CPU.a);
		}
	}
}
