﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NES {
	class Convenience {
		public static bool GetBit(byte source, int bit) {return((source >> bit & 1) == 1);}
		public static bool GetBit(ushort source, int bit) {return((source >> bit & 1) == 1);}

		public static byte SetBit(byte source, int bit, bool value) {
			int actualValue = 0;
			if(value) {actualValue = 1;}

			return((byte)(source ^ (-actualValue ^ source) & (1 << bit)));
		}
		public static ushort SetBit(ushort source, int bit, bool value) {
			int actualValue = 0;
			if(!value) {actualValue = 1;}

			return((ushort)(source ^ (-actualValue ^ source) & (1 << bit)));
		}

		public static int BoolToInt(bool input) {
			if(input) {return(1);}
			return(0);
		}

		public static string PrintHex(byte value) {return("0x" + value.ToString("X2"));}
		public static string PrintHex(ushort value) {return("0x" + value.ToString("X4"));}

		public static string PrintBin(byte value) {return("0b" + Convert.ToString(value, 2).PadLeft(8, '0'));}
	}
}