﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using static NES.Operations;
using static NES.AddressingModes;
using static NES.Convenience;

namespace NES.Components {
	class CPU {
		public static bool NMI {get; set;}

		public static byte a;
		public static byte x;
		public static byte y;
		public static ushort pc;
		public static byte sp;
		public static byte sr;

		public static int cycles;
		public static int elapsedCycles;

		static bool console;
		static bool testBool;

		public static void Initialize() {
			NMI = false;

			a = 0;
			x = 0;
			y = 0;
			pc = 0xFFB0;
			sp = 0xFD;
			sr = 0x04;

			console = false;
			testBool = false;
		}

		public static void Step() {
			//if(pc == 0xE321) {testBool = true;}
			//if(pc == 0xE321 && testBool) {console = true;}
			//if(pc == 0x8884) {System.Environment.Exit(0);}
			//if(pc == 0xC0CC) {Console.ReadKey();}

			//if(pc == 0xE692) {Console.WriteLine(Memory.ReadByte(0x030E));}

			//if(pc == 0xE31D) {console = true;}
			//if(pc == 0xE325) {console = false;}

			if(NMI) {
				NMI = false;
				Memory.PushShort(pc);
				Memory.PushByte(sr);
				pc = Memory.ReadShort(0xFFFA);
			}

			if(cycles <= 0) {
				if(cycles < 0) {cycles = 0;}

				byte instruction = Memory.ReadByte(pc);

				if(console) {
					Console.WriteLine("------------------------------");
					Console.WriteLine("Dot: " + PPU.dot);
					Console.WriteLine("Scanline: " + PPU.scanline);
					Console.WriteLine("------------------------------");
					Console.WriteLine("A: 0x" + a.ToString("X2"));
					Console.WriteLine("X: 0x" + x.ToString("X2"));
					Console.WriteLine("Y: 0x" + y.ToString("X2"));
					Console.WriteLine("Program counter: 0x" + pc.ToString("X4"));
					Console.WriteLine("Stack pointer: 0x" + sp.ToString("X2"));
					Console.WriteLine("              NV  DIZC");
					Console.WriteLine("CPU Status: " + PrintBin(sr));
					Console.WriteLine();
					Console.WriteLine("Current instruction: 0x" + instruction.ToString("X2"));
				}

				switch(instruction) {
					case(0x05): {ORA(ZeroPage()); break;}
					case(0x06): {ASL(ZeroPage()); break;}
					case(0x08): {PHP(); break;}
					case(0x09): {ORA(Immediate()); break;}
					case(0x0A): {ASL(); break;}
					case(0x0D): {ORA(Absolute()); break;}
					case(0x0E): {ASL(Absolute()); break;}
					case(0x10): {BPL(Relative()); break;}
					case(0x11): {ORA(IndirectY()); break;}
					case(0x15): {ORA(ZeroPageX()); break;}
					case(0x18): {CLC(); break;}
					case(0x19): {ORA(AbsoluteY()); break;}
					case(0x1D): {ORA(AbsoluteX()); break;}
					case(0x1E): {ASL(AbsoluteX()); break;}
					case(0x20): {JSR(Absolute()); break;}
					case(0x24): {BIT(ZeroPage()); break;}
					case(0x25): {AND(ZeroPage()); break;}
					case(0x26): {ROL(ZeroPage()); break;}
					case(0x28): {PLP(); break;}
					case(0x29): {AND(Immediate()); break;}
					case(0x2A): {ROL(); break;}
					case(0x2C): {BIT(Absolute()); break;}
					case(0x2D): {AND(Absolute()); break;}
					case(0x2E): {ROL(Absolute()); break;}
					case(0x30): {BMI(Relative()); break;}
					case(0x31): {AND(IndirectY()); break;}
					case(0x35): {AND(ZeroPageX()); break;}
					case(0x38): {SEC(); break;}
					case(0x39): {AND(AbsoluteY()); break;}
					case(0x3D): {AND(AbsoluteX()); break;}
					case(0x40): {RTI(); break;}
					case(0x45): {EOR(ZeroPage()); break;}
					case(0x46): {LSR(ZeroPage()); break;}
					case(0x48): {PHA(); break;}
					case(0x49): {EOR(Immediate()); break;}
					case(0x4A): {LSR(); break;}
					case(0x4C): {JMP(Absolute()); break;}
					case(0x4D): {EOR(Absolute()); break;}
					case(0x4E): {LSR(Absolute()); break;}
					case(0x50): {BVC(Relative()); break;}
					case(0x55): {EOR(ZeroPageX()); break;}
					case(0x5D): {EOR(AbsoluteX()); break;}
					case(0x60): {RTS(); break;}
					case(0x65): {ADC(ZeroPage()); break;}
					case(0x66): {ROR(ZeroPage()); break;}
					case(0x68): {PLA(); break;}
					case(0x69): {ADC(Immediate()); break;}
					case(0x6A): {ROR(); break;}
					case(0x6C): {JMP(Indirect()); break;}
					case(0x6D): {ADC(Absolute()); break;}
					case(0x6E): {ROR(Absolute()); break;}
					case(0x70): {BVS(Relative()); break;}
					case(0x71): {ADC(IndirectY()); break;}
					case(0x78): {SEI(); break;}
					case(0x79): {ADC(AbsoluteY()); break;}
					case(0x7D): {ADC(AbsoluteX()); break;}
					case(0x7E): {ROR(AbsoluteX()); break;}
					case(0x84): {STY(ZeroPage()); break;}
					case(0x85): {STA(ZeroPage()); break;}
					case(0x86): {STX(ZeroPage()); break;}
					case(0x88): {DEY(); break;}
					case(0x8A): {TXA(); break;}
					case(0x8C): {STY(Absolute()); break;}
					case(0x8D): {STA(Absolute()); break;}
					case(0x8E): {STX(Absolute()); break;}
					case(0x90): {BCC(Relative()); break;}
					case(0x91): {STA(IndirectY()); break;}
					case(0x94): {STY(ZeroPageX()); break;}
					case(0x95): {STA(ZeroPageX()); break;}
					case(0x98): {TYA(); break;}
					case(0x99): {STA(AbsoluteY()); break;}
					case(0x9A): {TXS(); break;}
					case(0x9D): {STA(AbsoluteX()); break;}
					case(0xA0): {LDY(Immediate());break; }
					case(0xA2): {LDX(Immediate()); break;}
					case(0xA4): {LDY(ZeroPage()); break;}
					case(0xA5): {LDA(ZeroPage()); break;}
					case(0xA6): {LDX(ZeroPage()); break;}
					case(0xA8): {TAY(); break;}
					case(0xA9): {LDA(Immediate()); break;}
					case(0xAA): {TAX(); break;}
					case(0xAC): {LDY(Absolute()); break;}
					case(0xAD): {LDA(Absolute()); break;}
					case(0xAE): {LDX(Absolute()); break;}
					case(0xB0): {BCS(Relative()); break;}
					case(0xB1): {LDA(IndirectY()); break;}
					case(0xB4): {LDY(ZeroPageX()); break;}
					case(0xB5): {LDA(ZeroPageX()); break;}
					case(0xB9): {LDA(AbsoluteY()); break;}
					case(0xBC): {LDY(AbsoluteX()); break;}
					case(0xBD): {LDA(AbsoluteX()); break;}
					case(0xBE): {LDX(AbsoluteY()); break;}
					case(0xC0): {CPY(Immediate()); break;}
					case(0xC4): {CPY(ZeroPage()); break;}
					case(0xC5): {CMP(ZeroPage()); break;}
					case(0xC6): {DEC(ZeroPage()); break;}
					case(0xC8): {INY(); break;}
					case(0xC9): {CMP(Immediate()); break;}
					case(0xCA): {DEX(); break;}
					case(0xCC): {CPY(Absolute()); break;}
					case(0xCD): {CMP(Absolute()); break;}
					case(0xCE): {DEC(Absolute()); break;}
					case(0xD0): {BNE(Relative()); break;}
					case(0xD6): {DEC(ZeroPageX()); break;}
					case(0xD8): {CLD(); break;}
					case(0xD9): {CMP(AbsoluteY()); break;}
					case(0xDD): {CMP(AbsoluteX()); break;}
					case(0xDE): {DEC(AbsoluteX()); break;}
					case(0xE0): {CPX(Immediate()); break;}
					case(0xE4): {CPX(ZeroPage()); break;}
					case(0xE5): {SBC(ZeroPage()); break;}
					case(0xE6): {INC(ZeroPage()); break;}
					case(0xE8): {INX(); break;}
					case(0xE9): {SBC(Immediate()); break;}
					case(0xEA): {break;}
					case(0xED): {SBC(Absolute()); break;}
					case(0xEE): {INC(Absolute()); break;}
					case(0xF0): {BEQ(Relative()); break;}
					case(0xFD): {SBC(AbsoluteX()); break;}
					case(0xFE): {INC(AbsoluteX()); break;}

					default: {
						Console.WriteLine();
						Console.WriteLine("Unknown instruction: " + PrintHex(instruction));
						Console.WriteLine("Program counter: " + PrintHex(pc));
						Console.ReadKey();
						System.Environment.Exit(1);
						break;
					}
				}

				cycles += Timing.Cycles[instruction];
				pc += (ushort)Timing.Lengths[instruction];

				if(console) {
					Console.WriteLine("Cycles: " + cycles);
					Console.WriteLine("Length: " + Timing.Lengths[instruction]);
				}
			}

			if(cycles != 0) {
				cycles--;
				elapsedCycles++;
			}
		}
	}
}
