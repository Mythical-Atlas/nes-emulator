﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using static NES.Convenience;

namespace NES.Components {
	class ROM {
		static byte[] ram;

		static byte[] data;

		static uint[] bankStarts;

		static int bank1;
		static int bank2;

		static int programROMBanks;
		static int characterROMBanks;

		static int loadRegisterWrites;

		static byte loadRegister;
		static byte controlRegister;

		public static void Load(string path) {
			ram = new byte[0x2000];

			try {data = File.ReadAllBytes(path);}
			catch(Exception e) {
				Console.WriteLine("Failed to load ROM: " + path);
				System.Environment.Exit(1);
			}

			Console.WriteLine("Loaded ROM: " + path);

			if(data[0] == 0x4E && data[1] == 0x45 && data[2] == 0x53 && data[3] == 0x1A) {
				Console.WriteLine("Recognized ROM format as iNES");

				programROMBanks = data[4];
				characterROMBanks = data[5];

				if((data[6] >> 4) + (data[7] & 0xF0) == 1) {
					Console.WriteLine("Recognized mapper as MMC1");

					// 8000 - BFFF = 16 kb prg rom bank 
					// C000 - FFFF = 16 kb prg rom bank

					bank1 = 0;
					bank2 = programROMBanks - 1;

					loadRegisterWrites = 0;
					loadRegister = 0;
					controlRegister = 0;

					bankStarts = new uint[programROMBanks];
					for(int i = 0; i < bankStarts.Length; i++) {bankStarts[i] = (uint)(i * 16 * 1024 + 16);}
				}
				else {
					Console.WriteLine("Unknown mapper");
					System.Environment.Exit(1);
				}

				Console.WriteLine("Program ROM banks (16 KB): " + programROMBanks);
				Console.WriteLine("Character ROM banks (8 KB): " + characterROMBanks);

				if(!GetBit(data[6], 0)) {Console.WriteLine("Mirroring: horizontal (vertical arrangement)");}
				else {Console.WriteLine("Mirroring: vertical (horizontal arrangement)");}

				if(GetBit(data[6], 1)) {Console.WriteLine("Cartridge contains battery-backed PRG RAM (0x6000-0x7FFF) or other persistent memory");}
				if(GetBit(data[6], 2)) {Console.WriteLine("512-byte trainer at 0x7000-0x71FF (stored before PRG data)");}
				if(GetBit(data[6], 3)) {Console.WriteLine("Ignore mirroring control or above mirroring bit; instead provide four-screen VRAM");}

				Console.WriteLine("Program RAM banks (8 KB): " + data[8]);
				Console.WriteLine();
			}
			else {
				Console.WriteLine("Unknown ROM format");
				System.Environment.Exit(1);
			}
		}

		public static byte ReadByte(ushort address) {
			if(address >= 0x6000 && address <= 0x7FFF) {return(ram[address - 0x6000]);}
			else if(address >= 0x8000 && address <= 0xBFFF) {return(data[address - 0x8000 + bankStarts[bank1]]);}
			else if(address >= 0xC000 && address <= 0xFFFF) {return(data[address - 0xC000 + bankStarts[bank2]]);}
			else {return(0);}
		}

		public static ushort ReadShort(ushort address) {return((ushort)((ReadByte((ushort)(address + 1)) << 8) + ReadByte(address)));}

		public static void WriteByte(ushort address, byte value) {
			if(address >= 0x6000 && address <= 0x7FFF) {ram[address - 0x6000] = value;}
			else {
				loadRegisterWrites++;
			
				if(value >= 0x80) {
					loadRegisterWrites = 0;
					loadRegister = 0;
				}
				else {
					loadRegister = (byte)(loadRegister >> 1);
					loadRegister = SetBit(loadRegister, 4, GetBit(value, 0));

					if(loadRegisterWrites == 5) {
						if(address >= 0x8000 && address <= 0x9FFF) {
							controlRegister = loadRegister;
						}
						else if(address >= 0xE000 && address <= 0xFFFF) {
							if(!GetBit(controlRegister, 2) && !GetBit(controlRegister, 3) || GetBit(controlRegister, 2) && !GetBit(controlRegister, 3)) {
								bank1 = 0;
								bank2 = programROMBanks - 1;
							}
							if(!GetBit(controlRegister, 2) && GetBit(controlRegister, 3)) {
								bank1 = 0;
								bank2 = loadRegister & 0b1111;
							}
							if(GetBit(controlRegister, 2) && GetBit(controlRegister, 3)) {
								bank1 = loadRegister & 0b1111;
								bank2 = programROMBanks - 1;
							}
						}

						loadRegisterWrites = 0;
					}
				}
			}
		}
	}
}
