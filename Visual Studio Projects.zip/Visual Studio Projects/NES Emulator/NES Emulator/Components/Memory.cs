﻿using NES.Emulation;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using static NES.Convenience;

namespace NES.Components {
	class Memory {
		static byte[] ram;

		public static void Initialize() {
			ram = new byte[0x0800];
		}
		
		public static byte ReadByte(ushort address) {
			     if(address >= 0x0000 && address <= 0x1FFF) {return(ram[address % 0x0800]);}
			else if(address == 0x2002) {
				byte oldStat = PPU.statusRegister;
				PPU.statusRegister = SetBit(PPU.statusRegister, 7, false);
				return(oldStat);
			}
			else if(address == 0x2007) {return(PPU.ReadDataRegister());}
			else if(address == 0x4016) {return(Controller.Read());}
			else if(address >= 0x4020 && address <= 0xFFFF) {return(ROM.ReadByte(address));}
			else {return(0);}
		}

		public static ushort ReadShort(ushort address) {return((ushort)((ReadByte((ushort)(address + 1)) << 8) + ReadByte(address)));}

		public static void WriteByte(ushort address, byte value) {
			if(address >= 0x0000 && address <= 0x1FFF) {ram[address % 0x0800] = value;}
			else if(address == 0x2000) {PPU.controlRegister = value;}
			else if(address == 0x2001) {PPU.maskRegister = value;}
			else if(address == 0x2005) {PPU.WriteScrollRegister(value);}
			else if(address == 0x2006) {PPU.WriteAddressRegister(value);}
			else if(address == 0x2007) {PPU.WriteDataRegister(value);}
			else if(address == 0x4014) {PPU.OAMDMA(value);}
			else if(address == 0x4016) {Controller.Write(value);}
			else if(address >= 0x6000) {ROM.WriteByte(address, value);}
		}

		public static void WriteShort(ushort address, ushort value) {
			WriteByte((ushort)(address + 1), (byte)(value >> 8));
			WriteByte(address, (byte)(value & 0xFF));
		}

		public static byte PopByte() {return(ram[0x100 + ++CPU.sp]);}
		public static ushort PopShort() {return((ushort)(PopByte() + (PopByte() << 8)));}
		public static void PushByte(byte value) {ram[0x100 + CPU.sp--] = value;}
		public static void PushShort(ushort value) {
			PushByte((byte)(value >> 8));
			PushByte((byte)(value & 0xFF));
		}
	}
}
