﻿using NES.Rendering;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Numerics;
using System.Text;
using System.Threading.Tasks;

using static NES.OpenGL.GL;
using static NES.Convenience;

namespace NES.Components {
	class PPU {
		static byte[] ram;
		static byte[] oam;

		public static byte controlRegister;
		public static byte maskRegister;
		public static byte statusRegister;
		public static ushort addressRegister;
		public static byte oamAddressRegister;
		public static byte oamDataRegister;
		static byte xScroll;
		static byte yScroll;

		public static int dot;
		public static int scanline;

		static int addressWrites;
		static int scrollWrites;

		public static void Initialize() {
			ram = new byte[0x4000];
			oam = new byte[0x100];

			controlRegister = 0;
			maskRegister = 0;
			statusRegister = 0;
			addressRegister = 0;

			dot = 0;
			scanline = 0;

			addressWrites = 0;
			scrollWrites = 0;
		}

		public static void WriteAddressRegister(byte value) {
			if(addressWrites == 0) {
				addressWrites = 1;
				
				addressRegister = (ushort)((addressRegister & 0x00FF) + (value << 8));
			}
			else {
				addressWrites = 0;

				addressRegister = (ushort)((addressRegister & 0xFF00) + value);
			}
		}

		public static void WriteDataRegister(byte value) {
			ram[addressRegister] = value;
			if(!GetBit(controlRegister, 2)) {addressRegister++;}
			else {addressRegister += 32;}
		}

		public static byte ReadDataRegister() {
			byte value = ram[addressRegister];
			if(!GetBit(controlRegister, 2)) {addressRegister++;}
			else {addressRegister += 32;}

			return(value);
		}

		public static void WriteScrollRegister(byte value) {
			if(scrollWrites == 0) {
				scrollWrites = 1;
				xScroll = value;
			}
			else {
				scrollWrites = 0;
				yScroll = value;
			}
		}

		public static void OAMDMA(byte page) {
			CPU.cycles += 513;
			if(CPU.elapsedCycles % 2 == 1) {CPU.cycles++;}

			for(int i = 0; i < 0x100; i++) {oam[i] = Memory.ReadByte((ushort)((page << 8) + i));}
		}

		public static void Step() {
			dot++;
			if(dot > 340) {
				dot = 0;
				scanline++;
				if(scanline > 261) {scanline = 0;}
			}

			//statusRegister = SetBit(statusRegister, 6, false);
			//if(dot < 256 && scanline < 240) {if(GetBGColorIndex(dot, scanline) != 0 && GetSpriteColorIndex(0, dot, scanline) != 0) {statusRegister = SetBit(statusRegister, 6, true);}}

			if(dot == 1 && scanline == 241) {
				statusRegister = SetBit(statusRegister, 7, true);
				if(GetBit(controlRegister, 7)) {CPU.NMI = true;}
			}
			if(dot == 1 && scanline == 261) {statusRegister = SetBit(statusRegister, 7, false);}
		}

		public static void Render(uint vao, uint vbo, Shader shader, Camera cam) {
			Vector3 backgroundColor = Colors.Values[ram[0x3F00]];

			glClearColor(backgroundColor.X / 256.0f, backgroundColor.Y / 256.0f, backgroundColor.Z / 256.0f, 1.0f);
			glClear(GL_COLOR_BUFFER_BIT);

			for(int i = 0; i < 64; i++) {
				bool priority = GetBit(oam[i * 4 + 2], 5); // 0 = in front of bg, 1 = behind

				if(priority) {RenderSprites(i, vao, vbo, shader, cam);}
			}

			TilePlane plane = new TilePlane();

			for(int x = 0; x < 256; x++) {
				for(int y = 0; y < 240; y++) {
					// nametable (gives pattern)
					// attribute (gives palette)
					// pattern (gives color index in palette)

					int cx = x / 8;
					int cy = y / 8;
					int ax = x / 32;
					int ay = y / 32;
					int px = x % 8;
					int py = y % 8;
					int bx = x / 16;
					int by = y / 16;
					int qx = bx % 2;
					int qy = by % 2;

					int pattern = ram[0x2000 + 0x400 * (controlRegister & 0b11) + cx + cy * 32];
					byte tempPalette = ram[0x23C0 + 0x400 * (controlRegister & 0b11) + ax + ay * 8];
					int color = BoolToInt(GetBit(ram[0x1000 + pattern * 16 + py], 7 - px)) + BoolToInt(GetBit(ram[0x1008 + pattern * 16 + py], 7 - px)) * 2;

					if(color != 0) {
						int palette = 0;
						if(qx == 0 && qy == 0) {palette = (tempPalette >> 0) & 0b11;}
						if(qx == 1 && qy == 0) {palette = (tempPalette >> 2) & 0b11;}
						if(qx == 0 && qy == 1) {palette = (tempPalette >> 4) & 0b11;}
						if(qx == 1 && qy == 1) {palette = (tempPalette >> 6) & 0b11;}

						Vector3 tempColor = Colors.Values[ram[0x3F00 + palette * 4 + color]];

						plane.SetPixel(new Vector2(x, y), new Vector4(tempColor.X / 256.0f, tempColor.Y / 256.0f, tempColor.Z / 256.0f, 1.0f));
					}
					else {plane.SetPixel(new Vector2(x, y), new Vector4(0, 0, 0, 0));}
				}
			}

			if(GetBit(maskRegister, 3)) {
				plane.SetPosition(new Vector2(-xScroll, yScroll));
				plane.Load(vao, vbo);
				plane.Render(vao, vbo, shader, cam);
			}

			for(int i = 0; i < 64; i++) {
				bool priority = GetBit(oam[i * 4 + 2], 5); // 0 = in front of bg, 1 = behind

				if(!priority) {RenderSprites(i, vao, vbo, shader, cam);}
			}
		}

		static void RenderSprites(int i, uint vao, uint vbo, Shader shader, Camera cam) {
			Sprite sprite = new Sprite(new Vector2(oam[i * 4 + 3], oam[i * 4]));

			ushort pattern = 0x0000;
			int palette = (oam[i * 4 + 2] & 0b11) + 4;
			bool xFlip = GetBit(oam[i * 4 + 2], 6);
			bool yFlip = GetBit(oam[i * 4 + 2], 7);

			if(GetBit(controlRegister, 3)) {pattern = 0x1000;}

			for(int x = 0; x < 8; x++) {
				for(int y = 0; y < 8; y++) {
					int tx = 7 - x;
					int ty = y;

					if(xFlip) {tx = x;}
					if(yFlip) {ty = 7 - y;}

					int color = BoolToInt(GetBit(ram[pattern + oam[i * 4 + 1] * 16 + ty], tx)) + BoolToInt(GetBit(ram[pattern + oam[i * 4 + 1] * 16 + ty + 8], tx)) * 2;

					if(color != 0) {
						Vector3 tempColor = Colors.Values[ram[0x3F00 + palette * 4 + color]];

						sprite.SetPixel(new Vector2(x, y), new Vector4(tempColor.X / 256.0f, tempColor.Y / 256.0f, tempColor.Z / 256.0f, 1.0f));
					}
					else {sprite.SetPixel(new Vector2(x, y), new Vector4(0, 0, 0, 0));}
				}
			}

			if(GetBit(maskRegister, 4)) {
				sprite.Load(vao, vbo);
				sprite.Render(vao, vbo, shader, cam);
			}
		}

		static int GetBGColorIndex(int x, int y) {
			int cx = x / 8;
			int cy = y / 8;
			int ax = x / 32;
			int ay = y / 32;
			int px = x % 8;
			int py = y % 8;
			int bx = x / 16;
			int by = y / 16;
			int qx = bx % 2;
			int qy = by % 2;

			int pattern = ram[0x2000 + 0x400 * (controlRegister & 0b11) + cx + cy * 32];
			byte tempPalette = ram[0x23C0 + 0x400 * (controlRegister & 0b11) + ax + ay * 8];
			int color = BoolToInt(GetBit(ram[0x1000 + pattern * 16 + py], 7 - px)) + BoolToInt(GetBit(ram[0x1008 + pattern * 16 + py], 7 - px)) * 2;

			return(color);
		}
		static int GetSpriteColorIndex(int i, int sx, int sy) {
			int x = sx - oam[i * 4 + 3];
			int y = sy - oam[i * 4];

			if(x < 0 || x >= 8 || y < 0 || y >= 8) {return(0);}

			ushort pattern = 0x0000;
			if(GetBit(controlRegister, 3)) {pattern = 0x1000;}

			int palette = (oam[i * 4 + 2] & 0b11) + 4;
			bool priority = GetBit(oam[i * 4 + 2], 5); // 0 = in front of bg, 1 = behind
			bool xFlip = GetBit(oam[i * 4 + 2], 6);
			bool yFlip = GetBit(oam[i * 4 + 2], 7);

			int tx = 7 - x;
			int ty = y;

			if(xFlip) {tx = x;}
			if(yFlip) {ty = 7 - y;}

			int color = BoolToInt(GetBit(ram[pattern + oam[i * 4 + 1] * 16 + ty], tx)) + BoolToInt(GetBit(ram[pattern + oam[i * 4 + 1] * 16 + ty + 8], tx)) * 2;

			return(color);
		}
	}
}
